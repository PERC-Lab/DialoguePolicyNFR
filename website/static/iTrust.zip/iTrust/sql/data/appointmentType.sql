INSERT INTO appointmenttype(appt_type,duration,price)
VALUES
('General Checkup', '45', '1000'),
('Mammogram', '60', '3000'),
('Physical', '15', '2000'),
('Colonoscopy', '90', '2500'),
('Ultrasound', '30', '500'),
('Consultation', '30', '1000');