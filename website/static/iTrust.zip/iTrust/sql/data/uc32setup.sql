
INSERT INTO icdcodes(Code, Description, Chronic) VALUES
('493.00', 'Asthma', 'yes'),
('389.99', 'Below Circulatory Disease', 'no'),
('390.00', 'Min Circulatory Disease', 'yes'),
('459.99', 'Max Circulatory Disease', 'yes'),
('460.00', 'Above Circulatory Disease', 'yes');
