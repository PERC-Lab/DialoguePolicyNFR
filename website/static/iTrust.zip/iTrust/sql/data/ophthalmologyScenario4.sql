/*Creates the Ophthalmology Office Visit Request for UC88 Acceptance Test 1*/
INSERT INTO ophthalmologySchedule(
	PATIENTMID,
	DOCTORMID,
	OID,
	dateTime,
	docLastName,
	docFirstName,
	comments,
	pending,
	accepted
)
VALUES (407,9000000085,1,'2016-12-20 15:00:00','Tran','Brooke','My eyes hurt',1,0);