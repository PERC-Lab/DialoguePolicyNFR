INSERT INTO message(message_id,parent_msg_id,original_msg_id,from_id,to_id,sent_date,message,subject,been_read)
VALUES
('1',null,null,'22','9000000007', '2012-04-01 14:05:45.0',	'I will not be able to make my next schedulded appointment.  Is there anyone who can book another time?','Appointment rescheduling','0'),
('2',null,'1','22','9000000003', '2012-04-01 14:05:45.0',	'I will not be able to make my next schedulded appointment.  Is there anyone who can book another time?','Appointment rescheduling','0'),
('3',null,'1','22','9000000000', '2012-04-01 14:05:45.0',	'I will not be able to make my next schedulded appointment.  Is there anyone who can book another time?','Appointment rescheduling','0');