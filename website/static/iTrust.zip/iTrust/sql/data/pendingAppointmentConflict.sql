INSERT INTO appointmentrequests (doctor_id, patient_id, sched_date, appt_type, comment, pending, accepted) VALUES
(9000000000, 25, CONCAT(CURDATE(), ' 23:59:59'), 'General Checkup', NULL, true, false);
INSERT INTO appointmentrequests (doctor_id, patient_id, sched_date, appt_type, comment, pending, accepted) VALUES
(9000000000, 1, CONCAT(CURDATE(), ' 23:59:59'), 'General Checkup', NULL, true, false);