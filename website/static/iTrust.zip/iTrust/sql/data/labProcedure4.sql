INSERT INTO labProcedure (
	labTechnicianID,
	officeVisitID,
	labProcedureCode,
	priority,
	isRestricted,
	status,
	commentary,
	results,
	updatedDate,
	confidenceIntervalLower,
	confidenceIntervalUpper,
	hcpMID
) VALUES (
	5000000001,
	3,
	"11111-2",
	2,
	true,
	5,
	"In completed status",
	"Results are complete",
	"1996-01-20 07:34:26",
	5,
	10,
	9000000001
);