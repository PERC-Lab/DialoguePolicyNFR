INSERT INTO officevisits(
	id,
	visitDate,
	HCPID,
	notes,
	PatientID
)
VALUES 
(2,'2005-10-11',9000000000,'Additional Test OV (2005-10-11)',1),
(99999,'2007-05-10',9000000000,'Additional Test OV (2007-05-10)',1);