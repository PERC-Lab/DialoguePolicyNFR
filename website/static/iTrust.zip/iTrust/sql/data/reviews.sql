  INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating, title) VALUES
    (2, 9000000000, '2014-01-08', 'ok', 2, 'Kelly Doctor is horrible!');
   
   INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating, title) VALUES
     (106, 9000000000, '2014-01-08', 'Ouch!', 4, 'Best doctor at this hospital!');
     
    INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating , title) VALUES
     (22, 9000000003, '2014-01-08', 'splendiferous', 5, 'Pretty happy');
     
    INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating , title) VALUES
    (2, 9000000003, '2014-01-08', 'blah', 4, 'Good service.');
    
    INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating , title) VALUES
    (106, 9000000000, '2014-01-08', 'And the duck says...', 1, 'So Bad.');
    
        INSERT INTO reviews(mid, pid, reviewdate, descriptivereview, rating , title) VALUES
    (106, 9000000000, '2014-01-08', 'sunny', 3, 'I am pretty happy');