/*Creates the Ophthalmology Office Visit for UC84 Acceptance Test 3*/
INSERT INTO ophthalmology(
	MID,
	dateVisit,
	docLastName,
	DocFirstName,
	vaNumOD,
	vaDenOD,
	vaNumOS,
	vaDenOS,
	sphereOD,
	sphereOS,
	cylinderOS,
	axisOS,
	addOD,
	addOS
)
VALUES (409,'2015-10-30','Tran','Brooke',20,18,20,40,0.75,0.50,-0.25,30,1.00,1.00);