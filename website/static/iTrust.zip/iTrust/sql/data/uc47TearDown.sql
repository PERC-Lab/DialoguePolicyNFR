DELETE FROM `hcpassignedhos` WHERE (`hosID`='471') AND (`HCPID`='4700000001');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='471') AND (`HCPID`='4700000002');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='472') AND (`HCPID`='4700000003');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='472') AND (`HCPID`='4700000004');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='473') AND (`HCPID`='4700000005');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='473') AND (`HCPID`='4700000006');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='474') AND (`HCPID`='4700000007');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='474') AND (`HCPID`='4700000008');
DELETE FROM `hcpassignedhos` WHERE (`hosID`='475') AND (`HCPID`='4700000009');

DELETE FROM `personnel` WHERE (`MID`='4700000001');
DELETE FROM `personnel` WHERE (`MID`='4700000002');
DELETE FROM `personnel` WHERE (`MID`='4700000003');
DELETE FROM `personnel` WHERE (`MID`='4700000004');
DELETE FROM `personnel` WHERE (`MID`='4700000005');
DELETE FROM `personnel` WHERE (`MID`='4700000006');
DELETE FROM `personnel` WHERE (`MID`='4700000007');
DELETE FROM `personnel` WHERE (`MID`='4700000008');
DELETE FROM `personnel` WHERE (`MID`='4700000009');

DELETE FROM `hospitals` WHERE (`HospitalID`='471');
DELETE FROM `hospitals` WHERE (`HospitalID`='472');
DELETE FROM `hospitals` WHERE (`HospitalID`='473');
DELETE FROM `hospitals` WHERE (`HospitalID`='474');
DELETE FROM `hospitals` WHERE (`HospitalID`='475');


