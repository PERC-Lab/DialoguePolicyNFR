INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(6, '2014-05-05', 'Breakfast', 'Cereal', 1, 80, 17, 480, 55, 0, 0, 22, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(7, '2014-05-05', 'Lunch', 'Hot dog', 2, 80, 8, 480, 25, 0, 0, 9, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(8, '2014-05-05', 'Dinner', 'Salad', 4, 80, 5, 480, 15, 0, 0, 5, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(9, '2014-05-06', 'Breakfast', 'Cereal', 1, 80, 16, 480, 53, 0, 0, 21, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(10, '2014-05-06', 'Lunch', 'Hot dog', 2, 80, 9, 480, 23, 0, 0, 10, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(11, '2014-05-06', 'Dinner', 'Salad', 4, 80, 5, 480, 15, 0, 0, 6, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(12, '2014-05-07', 'Breakfast', 'Cereal', 1, 80, 15, 480, 58, 0, 0, 20, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(13, '2014-05-07', 'Lunch', 'Hot dog', 2, 80, 9, 480, 22, 0, 0, 8, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(14, '2014-05-07', 'Dinner', 'Salad', 4, 80, 6, 480, 15, 0, 0, 7, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(15, '2014-05-08', 'Breakfast', 'Cereal', 1, 80, 16, 480, 48, 0, 0, 25, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(16, '2014-05-08', 'Lunch', 'Hot dog', 2, 80, 8, 480, 21, 0, 0, 11, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(17, '2014-05-08', 'Dinner', 'Salad', 4, 80, 5, 480, 17, 0, 0, 6, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(18, '2014-05-09', 'Breakfast', 'Cereal', 1, 80, 16, 480, 52, 0, 0, 26, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(19, '2014-05-09', 'Lunch', 'Hot dog', 2, 80, 9, 480, 28, 0, 0, 10, 1);
		
INSERT INTO foodEntry(EntryID, DateEaten, MealType, FoodName, Servings, Calories, Fat, Sodium, Carbs, Sugar, Fiber, Protein, PatientID)
		VALUES(20, '2014-05-09', 'Dinner', 'Salad', 6, 80, 5, 480, 13, 0, 0, 6, 1);