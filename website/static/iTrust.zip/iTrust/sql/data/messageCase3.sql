INSERT INTO message(message_id,parent_msg_id,from_id,to_id,sent_date,message,subject,been_read)
VALUES
('1',null,'2','9000000000','2010-03-25 16:15:00','Does the influenza vaccine have any side effects?','Influenza Vaccine','0'),
('2',null,'1','9000000000','2009-12-03 8:26:00','Do you think I should get the influenza shot this year?','Flu Season','0'),
('3',null,'2','9000000000','2010-03-25 16:30:00','Can I trust the vaccines at the pharmacy, or should I visit the health department?','RE: Influenza Vaccine','0'),
('4',null,'2','9000000000','2010-02-12 9:22:00','Thanks for scheduling the appointment!','RE: appointment','0'),
('5',null,'5','9000000000','2008-06-02 20:46:00','With a bad cough, high fever, and red skin, I would like to schedule an appointment - I think it could be influenza!','Bad cough','0'),
('6',null,'1','9000000003','2010-01-21 18:59:00','I want a flu shot, can you schedule an appointment?','Vaccines','0');