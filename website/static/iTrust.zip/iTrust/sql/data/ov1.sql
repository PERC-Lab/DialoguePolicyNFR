INSERT INTO officevisits(
	id,
	visitDate,
	HCPID,
	notes,
	HospitalID,
	PatientID
)
VALUES (1,'2005-10-10',9000000000,'Generated for Death for Patient: 1','1',1);