INSERT INTO sleepEntry(EntryID, Date, SleepType, Hours, PatientID)
		VALUES(78, '2012-12-14', 'Nap', 1.0, 1);
INSERT INTO sleepEntry(EntryID, Date, SleepType, Hours, PatientID)
		VALUES(79, '2012-12-12', 'Nightly', 2.0, 1);