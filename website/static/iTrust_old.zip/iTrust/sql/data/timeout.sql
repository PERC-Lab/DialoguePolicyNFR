DELETE FROM globalvariables WHERE Name='Timeout';

INSERT INTO globalvariables(Name, Value) VALUES ('Timeout', '20');