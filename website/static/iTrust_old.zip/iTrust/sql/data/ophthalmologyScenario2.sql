/*Creates the Ophthalmology Office Visit for UC83 Acceptance Test 2*/
INSERT INTO ophthalmology(
	MID,
	OID,
	dateVisit,
	docLastName,
	docFirstName,
	vaNumOD,
	vaDenOD,
	vaNumOS,
	vaDenOS,
	sphereOD,
	sphereOS,
	addOD,
	addOS
)
VALUES (408, 2,'2015-10-15','Tran','Brooke',20,10,20,40,1.75, 1.75, 1.25,1.25);