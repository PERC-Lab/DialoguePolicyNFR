INSERT INTO labProcedure (
	labTechnicianID,
	officeVisitID,
	labProcedureCode,
	priority,
	isRestricted,
	status,
	commentary,
	results,
	updatedDate,
	confidenceIntervalLower,
	confidenceIntervalUpper,
	hcpMID
) VALUES (
	5000000001,
	3,
	"45678-9",
	3,
	true,
	4,
	"In testing status",
	"No results yet",
	"2014-10-30 04:00:00",
	91,
	92,
	9000000001
);