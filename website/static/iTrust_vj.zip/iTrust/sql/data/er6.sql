INSERT INTO personnel(
MID,
AMID,
role,
lastName, 
firstName, 
address1,
address2,
city,
state,
zip,
phone,
specialty,
email)
VALUES (
9000000006,
null,
'er',
'Time',
'Justin',
'555 Wanahakalugi',
'',
'Honolulu',
'HI',
'96813',
'135-246-3579',
'',
'jtime@iTrust.or'
);

INSERT INTO users(MID, password, role, sQuestion, sAnswer) VALUES(9000000006, '30c952fab122c3f9759f02a6d95c3758b246b4fee239957b2d4fee46e26170c4', 'er', 'first letter?', 'a');
/*password: pw*/

