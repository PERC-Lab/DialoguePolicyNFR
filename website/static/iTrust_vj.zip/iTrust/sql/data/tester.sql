INSERT INTO users(MID, password, role) VALUES(9999999999, '30c952fab122c3f9759f02a6d95c3758b246b4fee239957b2d4fee46e26170c4', 'tester');
/* password: pw*/