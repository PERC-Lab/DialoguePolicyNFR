INSERT INTO labProcedure (
	labTechnicianID,
	officeVisitID,
	labProcedureCode,
	priority,
	isRestricted,
	status,
	commentary,
	results,
	updatedDate,
	confidenceIntervalLower,
	confidenceIntervalUpper,
	hcpMID
) VALUES (
	5000000001,
	3,
	"34567-8",
	3,
	false,
	3,
	"In received status",
	"No results yet",
	"2015-10-29 04:30:00",
	50,
	90,
	9000000001
);