INSERT INTO message(message_id,parent_msg_id,from_id,to_id,sent_date,message,subject,been_read)
VALUES
('1',null,'2','9000000000','2010-03-25 16:15:00','Does the influenza vaccine have any side effects?','Influenza Vaccine','0'),
('2',null,'2','9000000000','2010-02-12 9:22:00','Thanks for scheduling the appointment!','RE: appointment','0');