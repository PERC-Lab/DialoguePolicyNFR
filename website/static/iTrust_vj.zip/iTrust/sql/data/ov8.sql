DELETE FROM allergies WHERE PatientID = 2;
INSERT INTO allergies(PatientID,Code,Description, FirstFound) 
	VALUES (2, '081096', 'Aspirin','1999-03-14 20:00:00'); /*aspirin*/

